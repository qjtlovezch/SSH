create PROCEDURE add_emp
(eno NUMBER,
 ename VARCHAR2,
 salary NUMBER,
 dno NUMBER,
 job VARCHAR2 DEFAULT 'clerk'
)IS
BEGIN
 INSERT INTO emp
        (empno,ename,sal,job,deptno)
      VALUES
        (eno,ename,salary,job,dno);
END;
